﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CursoConsoleApplication
{
    class Produto
    {
        public int codigo { get; set; }
        public String descricao { get; set; }
        public double valor { get; set; }
        public String fabricante { get; set; }
    }
}
